/**
 * Type definitions for Mastery System Actors
 */

export interface MasteryActorData {
  type: 'character' | 'npc' | 'summon' | 'divine';
  system: CharacterData | NpcData | SummonData | DivineData;
}

// Attribute structure
export interface AttributeData {
  value: number;
  stones?: number;
}

// Mastery progression
export interface MasteryData {
  rank: number;
  points: number;
  experience: number;
}

// Health bar structure
export interface HealthBar {
  name: string;
  max: number;
  current: number;
  penalty: number;
}

// Combat stats
export interface CombatData {
  initiative: number;
  evade: number;
  armor: number;
  speed: number;
  // Derived fields (calculated from equipped items)
  armorTotal?: number;
  evadeTotal?: number;
  armorName?: string;
  shieldName?: string;
  activeWeaponName?: string;
  activeWeaponId?: string;
  armorId?: string;
  shieldId?: string;
}

// Resource tracking
export interface ResourceData {
  value: number;
  max: number;
}

export interface ResourcesData {
  reactions: ResourceData;
  movement: ResourceData;
  actions: ResourceData;
}

// === Character Data ===
export interface CharacterData {
  bio: {
    name: string;
    echo: string;
    concept: string;
    appearance: string;
    notes: string;
  };
  bloodColor?: string; // Hex color for blood pools (e.g., "#8b0000" for dark red)
  attributes: {
    might: AttributeData;
    agility: AttributeData;
    vitality: AttributeData;
    intellect: AttributeData;
    resolve: AttributeData;
    influence: AttributeData;
    wits: AttributeData;
  };
  mastery: MasteryData;
  stones: {
    total: number;
    vitality: number;
    current: number;
    maximum: number;
  };
  health: {
    bars: HealthBar[];
    currentBar: number;
    tempHP: number;
  };
  stress: {
    bars: HealthBar[]; // 4 bars: Healthy, Stressed, Not Well, Breaking
    currentBar: number;
  };
  combat: CombatData;
  resources: ResourcesData;
  skills: Record<string, number>;
  conditions: any[];
  notes: {
    schticks: string;
    faithFractures: string;
    background: string;
  };
  // Derived tracked resources for Combat Carousel module
  tracked?: {
    hp?: ResourceData;
    stress?: ResourceData;
    stones?: ResourceData;
  };
}

// Status effect structure
export interface StatusEffect {
  name: string;
  value?: number | null;
  source?: string;
  timestamp?: number;
}

// Attack Value structure for NPCs
export interface AttackValue {
  name: string;
  attackDice: string; // e.g., "9"
  damage: string; // e.g., "5d8"
  special?: string; // e.g., "Bleed", "Ignite", "Freeze"
  specialValue?: number; // e.g., 5
}

// Phase structure for Boss NPCs
export interface BossPhase {
  name: string; // e.g., "Phase 1", "Phase 2"
  health: {
    bars: HealthBar[];
    currentBar: number;
    tempHP: number;
  };
  combat: CombatData;
  savingThrows?: {
    body: number;
    mind: number;
    spirit: number;
  };
  attackValues?: AttackValue[];
  statusEffects?: StatusEffect[];
  divineCombat?: {
    startingPool: number;
    regeneration: number;
    basisAttack: number;
    basisDefense: number;
    vitality?: number;
  };
}

// === NPC Data ===
export interface NpcData {
  bloodColor?: string; // Hex color for blood pools (e.g., "#8b0000" for dark red)
  bio: {
    name: string;
    type: string;
    faction: string;
    description: string;
  };
  attributes: {
    might: AttributeData;
    agility: AttributeData;
    vitality: AttributeData;
    intellect: AttributeData;
    resolve: AttributeData;
    influence: AttributeData;
    wits: AttributeData;
  };
  mastery: {
    rank: number;
  };
  health: {
    bars: HealthBar[];
    currentBar: number;
    tempHP: number;
  };
  combat: CombatData;
  resources: ResourcesData;
  skills: Record<string, number>;
  savingThrows?: {
    body: number;
    mind: number;
    spirit: number;
  };
  attackValues?: AttackValue[];
  phases?: BossPhase[]; // For boss NPCs with multiple phases
  conditions: any[];
  statusEffects?: StatusEffect[];
  notes: string;
  divineCombat?: {
    startingPool: number;
    regeneration: number;
    basisAttack: number;
    basisDefense: number;
    vitality?: number;
  };
  // Derived tracked resources for Combat Carousel module
  tracked?: {
    hp?: ResourceData;
    stress?: ResourceData;
    stones?: ResourceData;
  };
}

// === Summon Data ===
export interface SummonData {
  bio: {
    name: string;
    summonType: string;
    duration: string;
    description: string;
  };
  attributes: {
    might: { value: number };
    agility: { value: number };
    vitality: { value: number };
    wits: { value: number };
  };
  health: {
    current: number;
    maximum: number;
  };
  combat: {
    evade: number;
    armor: number;
    speed: number;
  };
  abilities: any[];
  notes: string;
}

// === Divine Entity Data ===
export interface DivineData {
  bio: {
    name: string;
    title: string;
    description: string;
  };
  stones: {
    vitality: number;
    pool: number;
  };
  divineClash: {
    attack: number;
    defense: number;
    overhang: number;
  };
  artifacts: any[];
  notes: string;
}

































