/**
 * Mastery System / Destroyed Faith
 * Main module entry point for Foundry VTT v13
 */

// Immediate log to verify module is loading
console.log('Mastery System | Module file loaded');

import { MasteryActor } from './documents/actor.js';
import { MasteryItem } from './documents/item.js';
import { MasteryCharacterSheet } from './sheets/character-sheet.js';
import { MasteryNpcSheet } from './sheets/npc-sheet.js';
import { MasteryItemSheet } from './sheets/item-sheet.js';
// Combat hooks are imported dynamically to avoid build errors if dist/combat doesn't exist yet
// import { initializeCombatHooks } from '../dist/combat/initiative.js';
import { calculateStones } from './utils/calculations.js';
import { initializeTokenActionSelector } from './token-action-selector';
import { initializeTurnIndicator } from './turn-indicator';
import { handleRadialMenuOpened, handleRadialMenuClosed } from './radial-menu/rendering';
import { registerAttackRollClickHandler } from './chat/attack-roll-handler';
// Import combat-related modules statically
import { PassiveSelectionDialog } from './sheets/passive-selection-dialog.js';
import { rollInitiativeForAllCombatants } from './combat/initiative-roll.js';
import { InitiativeShopDialog } from './combat/initiative-shop-dialog.js';
import { CombatCarouselApp } from './ui/combat-carousel.js';
import { initializeStoneHooks } from './stones/stone-hooks.js';
import { initializeEncounterStart, beginEncounter } from './combat/encounter-start.js';
import { initializeSceneControls, initializeTokenHUDButton } from './ui/scene-controls-mastery.js';
import { openStonePowersForAllCombatants as openStonePowers, initializeStonePowersFlow } from './combat/stone-powers-flow.js';

// Dice roller functions are imported in sheets where needed

console.log('Mastery System | All imports completed');

// Register Handlebars helpers immediately (before init hook)
// This ensures they are available when templates are first rendered
registerHandlebarsHelpersImmediate();

/**
 * Initialize the Mastery System
 * This hook is called once when Foundry first starts up
 */
Hooks.once('init', async function() {
  console.log('Mastery System | Initializing Mastery System / Destroyed Faith');

  // Shim deprecated globals to the namespaced versions to suppress warnings (Foundry v13+)
  if (!(globalThis as any).FilePicker && (foundry as any)?.applications?.apps?.FilePicker?.implementation) {
    (globalThis as any).FilePicker = (foundry as any).applications.apps.FilePicker.implementation;
  }

  // Shim Application to V2 if available to silence V1 deprecation (non-breaking)
  if ((foundry as any)?.applications?.api?.ApplicationV2 && !(globalThis as any)._masteryAppPatched) {
    (globalThis as any).Application = (foundry as any).applications.api.ApplicationV2;
    (globalThis as any)._masteryAppPatched = true;
  }

  
  // Register custom Document classes
  CONFIG.Actor.documentClass = MasteryActor;
  CONFIG.Item.documentClass = MasteryItem;
  
  // Register custom sheet application classes
  // Register Character sheet first
  foundry.documents.collections.Actors.registerSheet('mastery-system', MasteryCharacterSheet, {
    types: ['character'],
    makeDefault: true,
    label: 'Mastery Character Sheet'
  });
  console.log('Mastery System | Registered Character Sheet');
  
  // Register NPC sheet
  foundry.documents.collections.Actors.registerSheet('mastery-system', MasteryNpcSheet, {
    types: ['npc'],
    makeDefault: true,
    label: 'Mastery NPC Sheet'
  });
  console.log('Mastery System | Registered NPC Sheet');
  
  // Register Item sheet
  foundry.documents.collections.Items.registerSheet('mastery-system', MasteryItemSheet, {
    makeDefault: true,
    label: 'Mastery Item Sheet'
  });
  console.log('Mastery System | Registered Item Sheet');
  
  // Register system settings
  registerSystemSettings();
  
  // Setup XP Management inline in settings
  setupXpManagementInline();
  
  // Handlebars helpers are already registered in registerHandlebarsHelpersImmediate()
  // No need to register again here

  // Register CONFIG constants
  registerConfigConstants();

  // Initialize scene controls
  initializeSceneControls();
  initializeTokenHUDButton();

  // Initialize stone powers flow system
  initializeStonePowersFlow();

  // Initialize combat hooks
  // Register combatStart hook directly here
  Hooks.on('combatStart', async (combat: Combat) => {
    console.log('Mastery System | Combat started, showing passive selection overlay');
    
    try {
      // Step 1: Show Passive Selection Dialog
      await PassiveSelectionDialog.showForCombat(combat);
      
      // Step 2: Wait a moment for players to finish selecting passives
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Step 3: Roll initiative for all combatants (NPCs auto, PCs with shop)
      await rollInitiativeForAllCombatants(combat);
      
      // Step 4: Open Combat Carousel
      CombatCarouselApp.open();
    } catch (error) {
      console.error('Mastery System | Error in combat start sequence', error);
    }
  });

  // Close carousel when combat ends
  Hooks.on('combatEnd', () => {
    console.log('Mastery System | Combat ended, closing carousel');
    CombatCarouselApp.close();
  });

  // Track previous round to detect round changes
  let previousRound: number = 0;

  // Update carousel when combat changes
  // Also detect round changes to open Stone Powers for new rounds
  Hooks.on('updateCombat', async (combat: Combat) => {
    // Update carousel
    const carousel = CombatCarouselApp.instance;
    if (carousel && (carousel as any).rendered) {
      (carousel as any).render({ force: false });
    }
    
    // Detect round changes
    const currentRound = combat.round ?? 0;
    
    // Check if round has increased (new round started)
    if (currentRound > previousRound && currentRound > 1) {
      console.log('Mastery System | Round changed from', previousRound, 'to', currentRound);
      
      // Open Stone Powers for all combatants in the new round
      // Only if combat has started (round > 0)
      if (combat.started && currentRound > 1) {
        try {
          await openStonePowers(combat, currentRound);
        } catch (error) {
          console.error('Mastery System | Error opening stone powers for new round', error);
        }
      }
    }
    
    // Update previous round
    previousRound = currentRound;
  });

  /**
   * Update initiative display in combat tracker for a specific combatant
   * @param combatant - The combatant to update
   * @param $html - Optional jQuery object of the combat tracker HTML (for use in renderCombatTracker hook)
   */
  function updateInitiativeDisplayInTracker(combatant: any, $html?: JQuery<HTMLElement>): void {
    if (!combatant || !combatant.id) return;
    
    // Get current initiative value - use fresh from combat.combatants
    const combat = game.combat;
    if (!combat) return;
    
    const freshCombatant = combat.combatants.get(combatant.id);
    if (!freshCombatant) return;
    
    // Try to get initiative from msInitiativeValue flag first (set by Initiative Shop)
    // Fall back to combatant.initiative if flag is not set
    const flagValue = freshCombatant.getFlag('mastery-system', 'msInitiativeValue');
    const initiativeValue = (flagValue !== null && flagValue !== undefined) ? flagValue : (freshCombatant.initiative ?? 0);
    
    console.log('Mastery System | [INITIATIVE DISPLAY] Updating tracker', {
      combatantId: freshCombatant.id,
      flagValue,
      combatantInitiative: freshCombatant.initiative,
      finalValue: initiativeValue
    });
    
    // Find the combatant element - use provided HTML or find in tracker
    let $combatant: JQuery<HTMLElement>;
    if ($html) {
      // Use provided HTML (from renderCombatTracker hook)
      $combatant = $html.find(`[data-combatant-id="${combatant.id}"]`);
    } else {
      // Find the combat tracker app
      const combatTrackerApp = (ui as any).combat;
      if (!combatTrackerApp || !combatTrackerApp.element) return;
      const $tracker = $(combatTrackerApp.element);
      $combatant = $tracker.find(`[data-combatant-id="${combatant.id}"]`);
    }
    
    if ($combatant.length === 0) return;
    
    const $tokenName = $combatant.find('.token-name');
    if ($tokenName.length === 0) return;
    
    // Remove existing initiative display
    $tokenName.find('.ms-initiative-value').remove();
    
    // Add updated initiative value
    const $initiativeSpan = $('<span class="ms-initiative-value">[' + initiativeValue + ']</span>');
    $tokenName.prepend($initiativeSpan);
  }

  // Update carousel when combatants change
  Hooks.on('createCombatant', () => {
    const carousel = CombatCarouselApp.instance;
    if (carousel && (carousel as any).rendered) {
      (carousel as any).render({ force: false });
    }
  });

  Hooks.on('updateCombatant', (_combat: any, combatant: any) => {
    // Update carousel
    const carousel = CombatCarouselApp.instance;
    if (carousel && (carousel as any).rendered) {
      (carousel as any).render({ force: false });
    }
    
    // Update initiative display in combat tracker
    updateInitiativeDisplayInTracker(combatant);
  });

  Hooks.on('deleteCombatant', () => {
    const carousel = CombatCarouselApp.instance;
    if (carousel && (carousel as any).rendered) {
      (carousel as any).render({ force: false });
    }
  });

  // Update carousel when canvas is ready (tokens might have changed)
  Hooks.on('canvasReady', () => {
    const carousel = CombatCarouselApp.instance;
    if (carousel && (carousel as any).rendered) {
      (carousel as any).render({ force: false });
    }
  });

  // Hide initiative roll button (d20) and add passive selection button in combat tracker
  // Also add End Turn button for current combatant
  Hooks.on('renderCombatTracker', (_app: any, html: any) => {
    // Convert html to jQuery if needed (Foundry v13 compatibility)
    let $html: JQuery<HTMLElement>;
    try {
      if (html && typeof html === 'object') {
        // Check if it's already a jQuery object
        if (html.jquery !== undefined && html.find !== undefined) {
          $html = html as JQuery<HTMLElement>;
        } else if (html instanceof HTMLElement || html instanceof DocumentFragment) {
          $html = $(html) as JQuery<HTMLElement>;
        } else if (html.length !== undefined && html[0] instanceof HTMLElement) {
          // Might be a jQuery-like object
          $html = $(html) as JQuery<HTMLElement>;
        } else {
          // Try to wrap it
          $html = $(html) as JQuery<HTMLElement>;
        }
      } else {
        $html = $(html) as JQuery<HTMLElement>;
      }
    } catch (e) {
      console.error('Mastery System | Error converting html to jQuery in renderCombatTracker:', e);
      return;
    }

    // Hide all initiative roll buttons
    $html.find('button[data-action="rollInitiative"]').css('display', 'none');

    // Add buttons to each combatant row for passive and initiative dialogs
    $html.find('.combatant').each((_index: number, combatantElement: HTMLElement) => {
      const $combatant = $(combatantElement);
      const combatantId = $combatant.data('combatant-id') || $combatant.attr('data-combatant-id');
      
      if (!combatantId) {
        console.warn('Mastery System | [COMBAT TRACKER DEBUG] Combatant element has no ID', combatantElement);
        return;
      }

      // Find the token-initiative div
      const $initiativeDiv = $combatant.find('.token-initiative');
      if ($initiativeDiv.length === 0) {
        console.warn('Mastery System | [COMBAT TRACKER DEBUG] token-initiative div not found for combatant', combatantId);
        return;
      }

      // Remove existing buttons to prevent duplicates
      $initiativeDiv.find('.ms-passive-btn, .ms-initiative-btn, .ms-end-turn-btn, .ms-stone-powers-btn').remove();
      
      // Get combatant data
      const combat = game.combat;
      if (!combat) return;
      
      const combatant = combat.combatants.get(combatantId);
      if (!combatant) return;
      
      // Get initiative value and display it before the name
      // Use the shared function to ensure consistency
      // Pass $html so the function can find the combatant in the rendered HTML
      updateInitiativeDisplayInTracker(combatant, $html);
      
      // Check if this is the current combatant
      const isCurrent = combat.combatant?.id === combatantId;
      
      // Add End Turn button for current combatant
      if (isCurrent) {
        const endTurnBtn = $('<button type="button" class="combatant-control ms-end-turn-btn" data-action="endTurn" data-combatant-id="' + combatantId + '" data-tooltip="End Turn" aria-label="End Turn" title="End Turn"><i class="fa-solid fa-hourglass-end"></i></button>');
        $initiativeDiv.append(endTurnBtn);
        
        endTurnBtn.off('click.ms-end-turn').on('click.ms-end-turn', async (ev: JQuery.ClickEvent) => {
          ev.preventDefault();
          ev.stopPropagation();
          
          const { requestEndTurn } = await import('./combat/end-turn.js');
          await requestEndTurn();
        });
      }

      // Add Passive Selection button
      const passiveBtn = $('<button type="button" class="combatant-control ms-passive-btn" data-action="selectPassives" data-combatant-id="' + combatantId + '" data-tooltip="Select Passives" aria-label="Select Passives" title="Select Passives"><i class="fa-solid fa-shield"></i></button>');
      $initiativeDiv.append(passiveBtn);

      // Add Initiative Shop button
      const initiativeBtn = $('<button type="button" class="combatant-control ms-initiative-btn" data-action="openInitiativeShop" data-combatant-id="' + combatantId + '" data-tooltip="Initiative Shop" aria-label="Initiative Shop" title="Initiative Shop"><i class="fa-solid fa-shop"></i></button>');
      $initiativeDiv.append(initiativeBtn);
      
      // Add Stone Powers button (only for characters)
      const actor = combatant.actor;
      if (actor && actor.type === 'character') {
        const stonePowersBtn = $('<button type="button" class="combatant-control ms-stone-powers-btn" data-action="openStonePowers" data-combatant-id="' + combatantId + '" data-tooltip="Stone Powers" aria-label="Stone Powers" title="Stone Powers"><i class="fa-solid fa-gem"></i></button>');
        $initiativeDiv.append(stonePowersBtn);
        
        stonePowersBtn.off('click.ms-stone-powers').on('click.ms-stone-powers', async (ev: JQuery.ClickEvent) => {
          ev.preventDefault();
          ev.stopPropagation();
          
          if (!actor) {
            ui.notifications?.error('Actor not found');
            return;
          }
          
          try {
            const { StonePowersDialog } = await import('./stones/stone-powers-dialog.js');
            await StonePowersDialog.showForActor(actor, combatant);
          } catch (error) {
            console.error('Mastery System | Error showing stone powers dialog', error);
            ui.notifications?.error('Failed to open stone powers dialog');
          }
        });
      }

      // Add click handlers
      passiveBtn.off('click.ms-passive').on('click.ms-passive', async (ev: JQuery.ClickEvent) => {
        console.log('Mastery System | [COMBAT TRACKER DEBUG] Passive button clicked', { combatantId });
        ev.preventDefault();
        ev.stopPropagation();
        
        const combat = game.combat;
        if (!combat) {
          ui.notifications?.warn('No active combat encounter');
          return;
        }

        const combatant = combat.combatants.get(combatantId);
        if (!combatant) {
          console.error('Mastery System | [COMBAT TRACKER DEBUG] Combatant not found', { combatantId });
          ui.notifications?.error('Combatant not found');
          return;
        }

        try {
          await PassiveSelectionDialog.showForCombatant(combatant);
        } catch (error) {
          console.error('Mastery System | [COMBAT TRACKER DEBUG] Error showing passive dialog', error);
          ui.notifications?.error('Failed to open passive selection dialog');
        }
      });

      initiativeBtn.off('click.ms-initiative').on('click.ms-initiative', async (ev: JQuery.ClickEvent) => {
        console.log('Mastery System | [COMBAT TRACKER DEBUG] Initiative button clicked', { combatantId });
        ev.preventDefault();
        ev.stopPropagation();
        
        const combat = game.combat;
        if (!combat) {
          ui.notifications?.warn('No active combat encounter');
          return;
        }

        const combatant = combat.combatants.get(combatantId);
        if (!combatant) {
          console.error('Mastery System | [COMBAT TRACKER DEBUG] Combatant not found', { combatantId });
          ui.notifications?.error('Combatant not found');
          return;
        }

        try {
          // Calculate base initiative
          const actor = combatant.actor;
          if (!actor) {
            ui.notifications?.error('Actor not found');
            return;
          }

          const { rollInitiativeForCombatant } = await import('./combat/initiative-roll.js');
          const breakdown = await rollInitiativeForCombatant(combatant);
          
          // Show initiative shop
          await InitiativeShopDialog.showForCombatant(combatant, breakdown, combat);
        } catch (error) {
          console.error('Mastery System | [COMBAT TRACKER DEBUG] Error showing initiative shop', error);
          ui.notifications?.error('Failed to open initiative shop');
        }
      });
    });

    // Add "Begin Encounter" and "Select Passives" buttons to encounter controls
    const encounterControls = $html.find('.encounter-controls');
    if (encounterControls.length > 0) {
      // Remove any existing buttons to prevent duplicates
      encounterControls.find('.ms-begin-encounter-btn, .ms-passive-selection-btn').remove();
      
      // Add button to the left control buttons area
      const leftControls = encounterControls.find('.control-buttons.left');
      if (leftControls.length > 0) {
        const combat = game.combat;
        
        // Add "Begin Encounter" button (GM only)
        if (combat && game.user?.isGM) {
          // Check if encounter setup has started
          const flags = combat.flags['mastery-system'] || {};
          const setup = flags.encounterSetup;
          const isStarted = setup?.started === true || combat.round > 0;
          
          const beginBtn = $('<button type="button" class="inline-control combat-control icon fa-solid fa-play ms-begin-encounter-btn" data-action="beginEncounter" data-tooltip="Begin Encounter" aria-label="Begin Encounter"></button>');
          
          if (isStarted) {
            beginBtn.prop('disabled', true).addClass('disabled');
            beginBtn.attr('data-tooltip', 'Encounter already initialized');
          }
          
          leftControls.prepend(beginBtn);
          
          // Add click handler
          beginBtn.off('click.ms-begin').on('click.ms-begin', async (ev: JQuery.ClickEvent) => {
            ev.preventDefault();
            ev.stopPropagation();
            
            const combat = game.combat;
            if (!combat) {
              ui.notifications?.warn('No active combat encounter');
              return;
            }

            // Check if already started
            const flags = combat.flags['mastery-system'] || {};
            const setup = flags.encounterSetup;
            if (setup?.started === true || combat.round > 0) {
              ui.notifications?.warn('Encounter already initialized');
              return;
            }

            try {
              await beginEncounter(combat);
            } catch (error) {
              console.error('Mastery System | Error beginning encounter', error);
              ui.notifications?.error('Failed to begin encounter');
            }
          });
        }
        
        // Add "Select Passives" button (legacy, for manual use)
        const passiveBtn = $('<button type="button" class="inline-control combat-control icon fa-solid fa-shield ms-passive-selection-btn" data-action="selectPassives" data-tooltip="Select Passives" aria-label="Select Passives"></button>');
        leftControls.append(passiveBtn);
        
        // Add click handler
        passiveBtn.off('click.ms-passive').on('click.ms-passive', async (ev: JQuery.ClickEvent) => {
          console.log('Mastery System | [PASSIVE DIALOG DEBUG] Button clicked in combat tracker');
          ev.preventDefault();
          ev.stopPropagation();
          
          const combat = game.combat;
          if (!combat) {
            console.log('Mastery System | [PASSIVE DIALOG DEBUG] No active combat');
            ui.notifications?.warn('No active combat encounter');
            return;
          }

          console.log('Mastery System | [PASSIVE DIALOG DEBUG] Opening dialog from button', {
            combatId: combat.id,
            combatants: combat.combatants.size
          });

          try {
            await PassiveSelectionDialog.showForCombat(combat);
            console.log('Mastery System | [PASSIVE DIALOG DEBUG] Dialog opened successfully from button');
          } catch (error) {
            console.error('Mastery System | [PASSIVE DIALOG DEBUG] Error showing passive selection dialog', error);
            ui.notifications?.error('Failed to open passive selection dialog');
          }
        });
      }
    }
  });

  // Cleanup: Remove any stray passive-selection-overlay and initiative-shop-dialog elements from body
  Hooks.on('renderApplication', (app: any) => {
    // If any application is rendered, check for stray overlay elements
    // This ensures cleanup even if the dialog wasn't closed properly
    if (app.id !== 'mastery-passive-selection') {
      $('body > .passive-selection-overlay').remove();
    }
    if (app.id !== 'mastery-initiative-shop') {
      $('body > .initiative-shop-dialog').remove();
    }
  });
  
  console.log('Mastery System | Combat hooks initialized');
  
  // Initialize stone system hooks (turn state, regen, restore)
  initializeStoneHooks();
  console.log('Mastery System | Stone system hooks initialized');

  // Initialize encounter start system
  initializeEncounterStart();
  console.log('Mastery System | Encounter start system initialized');

  // Initialize token action selector
  initializeTokenActionSelector();
  
  // Initialize turn indicator (blue ring around active combatant)
  initializeTurnIndicator();

  // Register radial menu hooks for hover preview suppression
  Hooks.on('masterySystem.radialMenuOpened', handleRadialMenuOpened);
  Hooks.on('masterySystem.radialMenuClosed', handleRadialMenuClosed);

  // Preload Handlebars templates
  await preloadTemplates();

  console.log('Mastery System | System initialized');
});

/**
 * Register Handlebars helpers immediately (before init)
 * This ensures helpers are available when templates are first rendered
 */
function registerHandlebarsHelpersImmediate() {
  // Default/fallback helper: {{default value fallback}}
  Handlebars.registerHelper('default', function (value: any, fallback: any) {
    return value !== undefined && value !== null ? value : fallback;
  });

  // Calculate stones from an attribute value: {{calculateStones value}}
  Handlebars.registerHelper('calculateStones', function (value: any) {
    const num = Number(value) || 0;
    return calculateStones(num);
  });

  // Repeat block n times: {{#times n}}...{{/times}}
  Handlebars.registerHelper('times', function (count: any, block: any) {
    const n = Number(count) || 0;
    let accum = '';
    for (let i = 0; i < n; i++) {
      accum += block.fn(i);
    }
    return accum;
  });

  // Simple arithmetic helpers
  Handlebars.registerHelper('add', function (a: any, b: any) {
    return (Number(a) || 0) + (Number(b) || 0);
  });

  Handlebars.registerHelper('subtract', function (a: any, b: any) {
    return (Number(a) || 0) - (Number(b) || 0);
  });

  // Helper to create arrays
  Handlebars.registerHelper('array', function(...args: any[]) {
    args.pop(); // Remove Handlebars options object
    return args;
  });

  // Helper for greater than comparison
  Handlebars.registerHelper('gt', function(a: number, b: number) {
    return (Number(a) || 0) > (Number(b) || 0);
  });

  // Helper for greater than or equal comparison
  Handlebars.registerHelper('gte', function(a: number, b: number) {
    return (Number(a) || 0) >= (Number(b) || 0);
  });

  // Helper for less than or equal comparison
  Handlebars.registerHelper('lte', function(a: number, b: number) {
    return (Number(a) || 0) <= (Number(b) || 0);
  });

  // Helper for less than comparison
  Handlebars.registerHelper('lt', function(a: number, b: number) {
    return (Number(a) || 0) < (Number(b) || 0);
  });

  // Helper for incrementing (for 1-based indexing)
  Handlebars.registerHelper('inc', function(value: number) {
    return parseInt(String(value)) + 1;
  });

  // Helper for creating a range array: {{#each (range 1 8)}}...{{/each}}
  Handlebars.registerHelper('range', function(start: number, end: number) {
    const startNum = Number(start) || 1;
    const endNum = Number(end) || 8;
    const result = [];
    for (let i = startNum; i <= endNum; i++) {
      result.push(i);
    }
    return result;
  });

  // Helper for multiplication
  Handlebars.registerHelper('multiply', function(a: number, b: number) {
    return a * b;
  });

  // Helper for division
  Handlebars.registerHelper('divide', function(a: number, b: number) {
    if (b === 0) return 0;
    return a / b;
  });

  // Helper to check if user is GM
  Handlebars.registerHelper('userIsGM', function() {
    return (game as any).user?.isGM ?? false;
  });

  // Helper for equality comparison
  Handlebars.registerHelper('eq', function(a: any, b: any) {
    return a === b;
  });

  // Helper for not equal comparison
  Handlebars.registerHelper('ne', function(a: any, b: any) {
    return a !== b;
  });

  // Helper to check if value is an array
  Handlebars.registerHelper('isArray', function(value: any) {
    return Array.isArray(value);
  });

  // Helper to capitalize first letter
  Handlebars.registerHelper('capitalize', function(str: string) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
  });

  // Helper to reduce array (sum)
  Handlebars.registerHelper('reduce', function(array: any[], initial: number, property: string) {
    if (!Array.isArray(array)) return initial;
    return array.reduce((sum, item) => sum + (item[property] || 0), initial);
  });

  // Helper to lookup value in object
  Handlebars.registerHelper('lookup', function(obj: any, key: string) {
    return obj && obj[key];
  });

  // Helper to check if array contains value
  Handlebars.registerHelper('contains', function(array: any[], value: any) {
    if (!Array.isArray(array)) return false;
    return array.includes(value);
  });

  // Helper to get type of value
  Handlebars.registerHelper('typeof', function(value: any) {
    return typeof value;
  });

  // Helper to determine power category (Melee/Melee AoE/Range/Range AoE)
  Handlebars.registerHelper('powerCategory', function(range: string, aoe: string) {
    const rangeStr = (range || '').toString().trim().toLowerCase();
    const aoeStr = (aoe || '').toString().trim();
    
    // Check if it's ranged (has range value and not melee)
    const hasRange = rangeStr !== '' && rangeStr !== '0m' && rangeStr !== '0' && !rangeStr.includes('melee') && !rangeStr.includes('touch');
    // Check if it has AoE
    const hasAoe = aoeStr !== '' && aoeStr !== '—' && aoeStr !== '-' && aoeStr !== 'none';
    
    if (hasRange && hasAoe) return 'Range AoE';
    if (hasRange) return 'Range';
    if (hasAoe) return 'Melee AoE';
    return 'Melee';
  });

  // Helper to format power type display
  Handlebars.registerHelper('powerTypeDisplay', function(powerType: string) {
    if (!powerType) return 'Active';
    const typeMap: Record<string, string> = {
      'active': 'Active',
      'buff': 'Active Buff',
      'utility': 'Active',
      'passive': 'Passive',
      'reaction': 'Reaction',
      'movement': 'Movement'
    };
    return typeMap[powerType.toLowerCase()] || 'Active';
  });

  // Helper to format damage display
  Handlebars.registerHelper('powerDamage', function(damage: string) {
    if (!damage || damage.trim() === '') return '—';
    return damage;
  });

  // Helper to format specials display
  Handlebars.registerHelper('powerSpecials', function(specials: string[]) {
    if (!specials || !Array.isArray(specials) || specials.length === 0) return '—';
    return specials.join(', ');
  });
}

/**
 * Apply theme class to document.body
 */
function applyThemeClass(theme: string): void {
  // Remove all existing theme classes
  document.body.classList.remove('ms-theme-rulebook', 'ms-theme-ember', 'ms-theme-ashen', 'ms-theme-bloodmoon');
  
  // Add new theme class
  if (theme) {
    document.body.classList.add(`ms-theme-${theme}`);
    console.log(`Mastery System | Applied theme: ${theme}`);
  }
}

/**
 * Register system settings
 */
function registerSystemSettings() {
  // Example setting: auto-calculate derived values
  (game as any).settings.register('mastery-system', 'autoCalculate', {
    name: 'Auto-Calculate Derived Values',
    hint: 'Automatically calculate Stones, Health Bars, and other derived values',
    scope: 'world',
    config: true,
    type: Boolean,
    default: true
  });
  
  // Debug mode
  (game as any).settings.register('mastery-system', 'debugMode', {
    name: 'Debug Mode',
    hint: 'Enable debug logging to console',
    scope: 'client',
    config: true,
    type: Boolean,
    default: false
  });

  // Mastery Rank - Global default
  (game as any).settings.register('mastery-system', 'defaultMasteryRank', {
    name: 'Default Mastery Rank',
    hint: 'Default Mastery Rank for all characters (can be overridden per player)',
    scope: 'world',
    config: true,
    type: Number,
    default: 2,
    range: {
      min: 1,
      max: 20,
      step: 1
    }
  });

  // Mastery Rank per player (stored as object with player IDs as keys)
  (game as any).settings.register('mastery-system', 'playerMasteryRanks', {
    name: 'Player Mastery Ranks',
    hint: 'Mastery Rank per player (overrides global default)',
    scope: 'world',
    config: false,
    type: Object,
    default: {}
  });

  // Combat Carousel Settings
  (game as any).settings.register('mastery-system', 'carouselResource1Path', {
    name: 'Carousel Resource 1 Path',
    hint: 'Path to first tracked resource (e.g., tracked.hp)',
    scope: 'world',
    config: true,
    type: String,
    default: 'tracked.hp'
  });

  (game as any).settings.register('mastery-system', 'carouselResource1Label', {
    name: 'Carousel Resource 1 Label',
    hint: 'Display label for first resource',
    scope: 'world',
    config: true,
    type: String,
    default: 'HP'
  });

  (game as any).settings.register('mastery-system', 'carouselResource2Path', {
    name: 'Carousel Resource 2 Path',
    hint: 'Path to second tracked resource (e.g., tracked.stress)',
    scope: 'world',
    config: true,
    type: String,
    default: 'tracked.stress'
  });

  (game as any).settings.register('mastery-system', 'carouselResource2Label', {
    name: 'Carousel Resource 2 Label',
    hint: 'Display label for second resource',
    scope: 'world',
    config: true,
    type: String,
    default: 'Stress'
  });

  // Character XP Management (inline in settings)
  (game as any).settings.register('mastery-system', 'characterXpManagement', {
    name: 'Character XP Management',
    hint: 'Manage Attribute XP and Mastery XP for all player characters',
    scope: 'world',
    config: true,
    type: Object,
    default: {},
    restricted: true
  });

  // Default scene background image
  (game as any).settings.register('mastery-system', 'defaultSceneImage', {
    name: 'Default Scene Background Image',
    hint: 'Default background image path for new scenes (leave empty to use Foundry default)',
    scope: 'world',
    config: true,
    type: String,
    default: 'systems/mastery-system/assets/banner.jpg',
    filePicker: 'image'
  });

  // UI Theme setting
  (game as any).settings.register('mastery-system', 'uiTheme', {
    name: 'UI Theme',
    hint: 'Choose the visual theme for Mastery System dialogs and UI',
    scope: 'world',
    config: true,
    type: String,
    choices: {
      'rulebook': 'Rulebook',
      'ember': 'Ember',
      'ashen': 'Ashen',
      'bloodmoon': 'Bloodmoon'
    },
    default: 'rulebook',
    onChange: (value: string) => {
      applyThemeClass(value);
    }
  });
}

/**
 * Setup XP Management inline in settings
 */
function setupXpManagementInline() {
  // Hook into settings rendering to add custom UI
  Hooks.on('renderSettingsConfig', (app: any, html: any, _data: any) => {
    // In Foundry v13, html might be an HTMLElement, jQuery, or a different structure
    // Convert to jQuery if needed
    let $html: JQuery<HTMLElement>;
    try {
      if (html && typeof html === 'object') {
        // Check if it's already a jQuery object
        if (html.jquery !== undefined && html.find !== undefined) {
          $html = html as JQuery<HTMLElement>;
        } else if (html instanceof HTMLElement || html instanceof DocumentFragment) {
          $html = $(html) as JQuery<HTMLElement>;
        } else if (html.length !== undefined && html[0] instanceof HTMLElement) {
          // Might be a jQuery-like object
          $html = $(html) as JQuery<HTMLElement>;
        } else {
          // Try to wrap it
          $html = $(html) as JQuery<HTMLElement>;
        }
      } else {
        $html = $(html) as JQuery<HTMLElement>;
      }
    } catch (e) {
      console.error('Mastery System | Error converting html to jQuery:', e);
      return;
    }
    
    // Find the Character XP Management setting
    const xpSetting = $html.find('[name="mastery-system.characterXpManagement"]').closest('.form-group');
    if (xpSetting.length === 0) {
      console.log('Mastery System | XP Management setting not found in settings');
      return;
    }
    
    // Replace the default input with our custom UI
    const settingInput = xpSetting.find('input, select, textarea');
    const customContainer = $('<div class="mastery-xp-management-inline"></div>');
    
    // Get all player characters
    const characters = (game as any).actors?.filter((actor: any) => actor.type === 'character') || [];
    
    // Build the UI
    let htmlContent = '<div class="xp-management-header"><h3><i class="fas fa-coins"></i> Character XP Management</h3></div>';
    
    // Bulk Grant Section
    htmlContent += '<div class="bulk-grant-section"><h4>Bulk Grant XP</h4>';
    htmlContent += '<div class="bulk-grant-controls">';
    htmlContent += '<div class="bulk-grant-group"><label>Attribute XP:</label>';
    htmlContent += '<input type="number" class="bulk-xp-amount" data-xp-type="attribute" min="0" value="0" />';
    htmlContent += '<button type="button" class="bulk-grant-btn" data-xp-type="attribute"><i class="fas fa-gift"></i> Grant to All</button></div>';
    htmlContent += '<div class="bulk-grant-group"><label>Mastery XP:</label>';
    htmlContent += '<input type="number" class="bulk-xp-amount" data-xp-type="mastery" min="0" value="0" />';
    htmlContent += '<button type="button" class="bulk-grant-btn" data-xp-type="mastery"><i class="fas fa-gift"></i> Grant to All</button></div>';
    htmlContent += '</div></div>';
    
    // Characters Table
    htmlContent += '<div class="characters-list"><table class="xp-table"><thead><tr>';
    htmlContent += '<th>Character</th><th>Player</th><th>Attribute XP</th><th>Mastery XP</th><th>Grant XP</th>';
    htmlContent += '</tr></thead><tbody>';
    
    if (characters.length === 0) {
      htmlContent += '<tr><td colspan="5" class="empty-message"><i class="fas fa-info-circle"></i> No player characters found.</td></tr>';
    } else {
      characters.forEach((actor: any) => {
        const system = actor.system || {};
        const points = system.points || {};
        
        // Calculate spent XP
        let attributeXPSpent = 0;
        if (system.attributes) {
          Object.values(system.attributes).forEach((attr: any) => {
            if (attr && typeof attr.value === 'number') {
              const baseValue = 2;
              const currentValue = attr.value || baseValue;
              if (currentValue > baseValue) {
                for (let val = baseValue + 1; val <= currentValue; val++) {
                  let cost = 1;
                  if (val >= 9 && val <= 16) cost = 2;
                  else if (val >= 17 && val <= 24) cost = 3;
                  else if (val >= 25 && val <= 32) cost = 4;
                  else if (val >= 33) cost = 5;
                  attributeXPSpent += cost;
                }
              }
            }
          });
        }
        
        let masteryXPSpent = 0;
        if (system.skills) {
          Object.values(system.skills).forEach((skillValue: any) => {
            if (typeof skillValue === 'number' && skillValue > 0) {
              for (let level = 1; level < skillValue; level++) {
                masteryXPSpent += level;
              }
            }
          });
        }
        
        const attributeXPAvailable = points.attribute || 0;
        const masteryXPAvailable = points.mastery || 0;
        const playerName = (game as any).users?.find((u: any) => u.character?.id === actor.id)?.name || 'Unassigned';
        
        htmlContent += `<tr data-character-id="${actor.id}">`;
        htmlContent += `<td class="character-cell"><img src="${actor.img}" alt="${actor.name}" class="character-avatar" /><span class="character-name">${actor.name}</span></td>`;
        htmlContent += `<td class="player-cell">${playerName}</td>`;
        htmlContent += `<td class="xp-cell attribute-xp"><div class="xp-info">`;
        htmlContent += `<span class="xp-spent">Spent: <strong>${attributeXPSpent}</strong></span> `;
        htmlContent += `<span class="xp-available">Available: <strong>${attributeXPAvailable}</strong></span> `;
        htmlContent += `<span class="xp-total">Total: <strong>${attributeXPSpent + attributeXPAvailable}</strong></span>`;
        if (attributeXPAvailable > 0) {
          htmlContent += `<button type="button" class="remove-xp-btn" data-character-id="${actor.id}" data-xp-type="attribute" data-amount="${attributeXPAvailable}" title="Remove all available Attribute XP"><i class="fas fa-minus"></i> Remove All</button>`;
        }
        htmlContent += `</div></td>`;
        htmlContent += `<td class="xp-cell mastery-xp"><div class="xp-info">`;
        htmlContent += `<span class="xp-spent">Spent: <strong>${masteryXPSpent}</strong></span> `;
        htmlContent += `<span class="xp-available">Available: <strong>${masteryXPAvailable}</strong></span> `;
        htmlContent += `<span class="xp-total">Total: <strong>${masteryXPSpent + masteryXPAvailable}</strong></span>`;
        if (masteryXPAvailable > 0) {
          htmlContent += `<button type="button" class="remove-xp-btn" data-character-id="${actor.id}" data-xp-type="mastery" data-amount="${masteryXPAvailable}" title="Remove all available Mastery XP"><i class="fas fa-minus"></i> Remove All</button>`;
        }
        htmlContent += `</div></td>`;
        htmlContent += `<td class="grant-cell"><div class="grant-controls">`;
        htmlContent += `<div class="grant-group"><input type="number" class="xp-amount-input" data-xp-type="attribute" data-character-id="${actor.id}" min="0" value="0" placeholder="AP" />`;
        htmlContent += `<button type="button" class="grant-xp-btn" data-character-id="${actor.id}" data-xp-type="attribute" title="Grant Attribute XP"><i class="fas fa-plus"></i></button></div>`;
        htmlContent += `<div class="grant-group"><input type="number" class="xp-amount-input" data-xp-type="mastery" data-character-id="${actor.id}" min="0" value="0" placeholder="MP" />`;
        htmlContent += `<button type="button" class="grant-xp-btn" data-character-id="${actor.id}" data-xp-type="mastery" title="Grant Mastery XP"><i class="fas fa-plus"></i></button></div>`;
        htmlContent += `</div></td></tr>`;
      });
    }
    
    htmlContent += '</tbody></table></div>';
    customContainer.html(htmlContent);
    
    // Replace the input
    settingInput.hide();
    settingInput.after(customContainer);
    
    // Add event listeners
    customContainer.find('.grant-xp-btn').on('click', async (event) => {
      const button = $(event.currentTarget);
      const characterId = button.data('character-id');
      const xpType = button.data('xp-type');
      const amount = parseInt(button.siblings(`.xp-amount-input[data-xp-type="${xpType}"]`).val() as string) || 0;
      
      if (amount <= 0) {
        ui.notifications?.warn('Please enter a valid amount greater than 0.');
        return;
      }
      
      const actor = (game as any).actors?.get(characterId);
      if (!actor) {
        ui.notifications?.error('Character not found.');
        return;
      }
      
      const currentPoints = (actor.system?.points?.[xpType] || 0);
      await actor.update({
        [`system.points.${xpType}`]: currentPoints + amount
      });
      
      ui.notifications?.info(`Granted ${amount} ${xpType === 'attribute' ? 'Attribute' : 'Mastery'} XP to ${actor.name}.`);
      
      // Re-render settings to update display
      app.render();
    });
    
    // Bulk grant
    customContainer.find('.bulk-grant-btn').on('click', async (event) => {
      const button = $(event.currentTarget);
      const xpType = button.data('xp-type');
      const amount = parseInt(customContainer.find(`.bulk-xp-amount[data-xp-type="${xpType}"]`).val() as string) || 0;
      
      if (amount <= 0) {
        ui.notifications?.warn('Please enter a valid amount greater than 0.');
        return;
      }
      
      const characters = (game as any).actors?.filter((actor: any) => actor.type === 'character') || [];
      let updated = 0;
      
      for (const actor of characters) {
        const currentPoints = (actor.system?.points?.[xpType] || 0);
        await actor.update({
          [`system.points.${xpType}`]: currentPoints + amount
        });
        updated++;
      }
      
      ui.notifications?.info(`Granted ${amount} ${xpType === 'attribute' ? 'Attribute' : 'Mastery'} XP to ${updated} characters.`);
      
      // Re-render settings to update display
      app.render();
    });
    
    // Handle remove XP buttons
    customContainer.find('.remove-xp-btn').on('click', async (event) => {
      const button = $(event.currentTarget);
      const characterId = button.data('character-id');
      const xpType = button.data('xp-type');
      const amount = parseInt(button.data('amount') as string) || 0;
      
      if (amount <= 0) {
        ui.notifications?.warn('No XP to remove.');
        return;
      }
      
      const actor = (game as any).actors?.get(characterId);
      if (!actor) {
        ui.notifications?.error('Character not found.');
        return;
      }
      
      const currentPoints = (actor.system?.points?.[xpType] || 0);
      const newPoints = Math.max(0, currentPoints - amount);
      await actor.update({
        [`system.points.${xpType}`]: newPoints
      });
      
      ui.notifications?.info(`Removed ${amount} ${xpType === 'attribute' ? 'Attribute' : 'Mastery'} XP from ${actor.name}.`);
      
      // Re-render settings to update display
      app.render();
    });
  });
}

/**
 * Preload Handlebars templates
 */
async function preloadTemplates() {
  const templatePaths = [
    // Actor sheets (only load existing templates)
    'systems/mastery-system/templates/actor/character-sheet.hbs',
    'systems/mastery-system/templates/actor/npc-sheet.hbs',
    
    // Item sheets (only load existing templates)
    'systems/mastery-system/templates/item/power-sheet.hbs',
    
    // Dice dialogs
    'systems/mastery-system/templates/dice/damage-dialog.hbs',
    
    // Character creation wizard
    'systems/mastery-system/templates/dialogs/disadvantage-config.hbs'
  ];
  
  try {
    await foundry.applications.handlebars.loadTemplates(templatePaths);
  } catch (error) {
    console.warn('Mastery System | Some templates could not be loaded:', error);
  }
}

/**
 * Register CONFIG constants
 */
function registerConfigConstants() {
  if (!(CONFIG as any).MASTERY) {
    (CONFIG as any).MASTERY = {};
  }
  
  (CONFIG as any).MASTERY.creation = {
    schticksAllowed: 2, // Number of schticks players must choose during creation
    attributePoints: 16,
    skillPoints: 16,  // Configurable - can be changed later
    maxAttributeAtCreation: 8,
    maxSkillAtCreation: 4,
    maxDisadvantagePoints: 8
  };
}

/**
 * Character Creation Hooks
 */
/**
 * Normalize health.bars from object to array format
 * This ensures health bars are always stored as arrays, not objects
 */
function normalizeHealthBars(health: any): any {
  if (!health || !health.bars) {
    return health;
  }
  
  const bars = health.bars;
  // If bars is an object (not an array), convert to array
  if (!Array.isArray(bars) && typeof bars === 'object') {
    const barsArray = Object.keys(bars)
      .sort((a, b) => parseInt(a) - parseInt(b))
      .map(key => bars[key]);
    health.bars = barsArray;
  }
  
  // Ensure each bar has required fields
  // Only set defaults if the value is missing (undefined/null), not if it's 0
  if (Array.isArray(health.bars)) {
    health.bars = health.bars.map((bar: any, index: number) => ({
      name: bar.name || `Bar ${index + 1}`,
      max: (bar.max !== undefined && bar.max !== null) ? bar.max : 30,
      current: (bar.current !== undefined && bar.current !== null) ? bar.current : ((bar.max !== undefined && bar.max !== null) ? bar.max : 30),
      penalty: (bar.penalty !== undefined && bar.penalty !== null) ? bar.penalty : 0
    }));
  }
  
  return health;
}

/**
 * Hook to normalize health.bars before actor updates
 * Ensures health.bars is always stored as an array, not an object
 */
Hooks.on('preUpdateActor', (actor: any, updateData: any, _options: any, _userId: string) => {
  if (actor.type === 'npc') {
    // Normalize main health bars
    if (updateData.system?.health?.bars) {
      updateData.system.health = normalizeHealthBars(updateData.system.health);
    }
    
    // Normalize phase health bars
    if (updateData.system?.phases && Array.isArray(updateData.system.phases)) {
      updateData.system.phases = updateData.system.phases.map((phase: any) => {
        if (phase.health?.bars) {
          phase.health = normalizeHealthBars(phase.health);
        }
        return phase;
      });
    }
  }
});

Hooks.on('preCreateActor', async (actor: any, data: any, _options: any, _userId: string) => {
  // Set creationComplete=false for new character actors
  if (actor.type === 'character') {
    if (!data.system) {
      data.system = {};
    }
    // Initialize schticks if not present
    if (!data.system.schticks) {
      data.system.schticks = { ranks: [] };
    }
    if (!data.system.creation) {
      data.system.creation = {};
    }
    data.system.creation.complete = false;
    console.log('Mastery System | New character created - setting creationComplete=false');
  }
  
  // Initialize NPCs with health bars (5 bars for characters, 1 for NPCs)
  if (actor.type === 'npc' || actor.type === 'character') {
    if (!data.system) {
      data.system = {};
    }
    
    // Initialize health bars
    if (!data.system.health) {
      if (actor.type === 'character') {
        // Characters: 5 bars (Healthy, Bruised, Injured, Wounded, Incapacitated)
        const vitality = data.system.attributes?.vitality?.value || 2;
        const maxHP = vitality * 2;
        data.system.health = {
          bars: [
            { name: 'Healthy', max: maxHP, current: maxHP, penalty: 0 },
            { name: 'Bruised', max: maxHP, current: maxHP, penalty: -1 },
            { name: 'Injured', max: maxHP, current: maxHP, penalty: -2 },
            { name: 'Wounded', max: maxHP, current: maxHP, penalty: -4 },
            { name: 'Incapacitated', max: maxHP, current: maxHP, penalty: 0 }
          ],
          currentBar: 0,
          tempHP: 0
        };
      } else {
        // NPCs: 1 bar
        data.system.health = {
          bars: [
            { name: 'Healthy', max: 30, current: 30, penalty: 0 }
          ],
          currentBar: 0,
          tempHP: 0
        };
      }
    } else {
      // Ensure health bars exist
      if (!data.system.health.bars || data.system.health.bars.length === 0) {
        if (actor.type === 'character') {
          const vitality = data.system.attributes?.vitality?.value || 2;
          const maxHP = vitality * 2;
          data.system.health.bars = [
            { name: 'Healthy', max: maxHP, current: maxHP, penalty: 0 },
            { name: 'Bruised', max: maxHP, current: maxHP, penalty: -1 },
            { name: 'Injured', max: maxHP, current: maxHP, penalty: -2 },
            { name: 'Wounded', max: maxHP, current: maxHP, penalty: -4 },
            { name: 'Incapacitated', max: maxHP, current: maxHP, penalty: 0 }
          ];
        } else {
          data.system.health.bars = [
            { name: 'Healthy', max: 30, current: 30, penalty: 0 }
          ];
        }
      } else if (actor.type === 'character' && data.system.health.bars.length < 5) {
        // Add missing bars for characters
        const vitality = data.system.attributes?.vitality?.value || 2;
        const maxHP = vitality * 2;
        const allBarNames = ['Healthy', 'Bruised', 'Injured', 'Wounded', 'Incapacitated'];
        const penalties = [0, -1, -2, -4, 0];
        
        for (let i = data.system.health.bars.length; i < 5; i++) {
          data.system.health.bars.push({
            name: allBarNames[i],
            max: maxHP,
            current: maxHP,
            penalty: penalties[i]
          });
        }
      }
      if (data.system.health.currentBar === undefined) {
        data.system.health.currentBar = 0;
      }
      if (data.system.health.tempHP === undefined) {
        data.system.health.tempHP = 0;
      }
    }
    
    // Initialize stress bars for characters only
    if (actor.type === 'character') {
      if (!data.system.stress) {
        const resolve = data.system.attributes?.resolve?.value || 2;
        const wits = data.system.attributes?.wits?.value || 2;
        const maxStress = (resolve + wits) * 2;
        data.system.stress = {
          bars: [
            { name: 'Healthy', max: maxStress, current: maxStress, penalty: 0 },
            { name: 'Stressed', max: maxStress, current: maxStress, penalty: 0 },
            { name: 'Not Well', max: maxStress, current: maxStress, penalty: 0 },
            { name: 'Breaking', max: maxStress, current: maxStress, penalty: 0 },
            { name: 'Breakdown', max: maxStress, current: maxStress, penalty: 0 }
          ],
          currentBar: 0
        };
      } else {
        // Migrate old format if needed
        if (!data.system.stress.bars || data.system.stress.bars.length === 0) {
          const resolve = data.system.attributes?.resolve?.value || 2;
          const wits = data.system.attributes?.wits?.value || 2;
          const maxStress = (resolve + wits) * 2;
          const oldCurrent = data.system.stress.current || 0;
          
          data.system.stress.bars = [
            { name: 'Healthy', max: maxStress, current: maxStress, penalty: 0 },
            { name: 'Stressed', max: maxStress, current: maxStress, penalty: 0 },
            { name: 'Not Well', max: maxStress, current: maxStress, penalty: 0 },
            { name: 'Breaking', max: maxStress, current: maxStress, penalty: 0 },
            { name: 'Breakdown', max: maxStress, current: maxStress, penalty: 0 }
          ];
          data.system.stress.currentBar = 0;
          
          // Distribute old stress
          if (oldCurrent > 0) {
            let remaining = oldCurrent;
            for (let i = 0; i < data.system.stress.bars.length && remaining > 0; i++) {
              if (remaining >= data.system.stress.bars[i].max) {
                data.system.stress.bars[i].current = 0;
                remaining -= data.system.stress.bars[i].max;
                data.system.stress.currentBar = i + 1;
              } else {
                data.system.stress.bars[i].current = data.system.stress.bars[i].max - remaining;
                remaining = 0;
              }
            }
          }
        } else if (data.system.stress.bars.length < 5) {
          // Add missing bars
          const resolve = data.system.attributes?.resolve?.value || 2;
          const wits = data.system.attributes?.wits?.value || 2;
          const maxStress = (resolve + wits) * 2;
          const allBarNames = ['Healthy', 'Stressed', 'Not Well', 'Breaking', 'Breakdown'];
          
          for (let i = data.system.stress.bars.length; i < 5; i++) {
            data.system.stress.bars.push({
              name: allBarNames[i],
              max: maxStress,
              current: maxStress,
              penalty: 0
            });
          }
        }
        if (data.system.stress.currentBar === undefined) {
          data.system.stress.currentBar = 0;
        }
      }
    }
    
    // Initialize statusEffects array
    if (!data.system.statusEffects) {
      data.system.statusEffects = [];
    }
    
    // Initialize stonePools for characters
    if (actor.type === 'character') {
      if (!data.system.stonePools) {
        data.system.stonePools = {};
      }
      
      // Initialize pools for all attributes (will be calculated properly in prepareBaseData)
      const attributeKeys = ['might', 'agility', 'vitality', 'intellect', 'resolve', 'influence'] as const;
      for (const attrKey of attributeKeys) {
        if (!data.system.stonePools[attrKey]) {
          const attrValue = data.system.attributes?.[attrKey]?.value || 0;
          const maxStones = Math.floor(attrValue / 8);
          data.system.stonePools[attrKey] = {
            current: maxStones,
            max: maxStones,
            sustained: 0
          };
        }
      }
    }
    
    console.log('Mastery System | New NPC created - initialized with 30 HP and statusEffects');
  }
});

// Post-create hook to add default weapon if needed
Hooks.on('createActor', async (actor: any, _options: any, _userId: string) => {
  // Only add default weapon for characters and NPCs
  if (actor.type !== 'character' && actor.type !== 'npc') {
    return;
  }
  
  // Only add if this is the creating user (not a sync from another client)
  if (_userId !== (game as any).user?.id) {
    return;
  }
  
  try {
    // Check if actor has any weapon items
    const items = actor.items || [];
    const hasWeapon = items.some((item: any) => item.type === 'weapon');
    
    if (!hasWeapon) {
      // Create default "Unarmed" weapon
      const unarmedWeapon = {
        name: 'Unarmed',
        type: 'weapon',
        system: {
          weaponType: 'melee',
          damage: '1d8',
          range: '0m',
          specials: [],
          equipped: true,
          hands: 1,
          innateAbilities: [],
          description: 'Basic unarmed strikes using fists, feet, or natural weapons.'
        }
      };
      
      await actor.createEmbeddedDocuments('Item', [unarmedWeapon]);
      console.log(`Mastery System | Added default "Unarmed" weapon to ${actor.name}`);
    }
  } catch (error) {
    console.warn('Mastery System | Could not add default weapon to actor:', error);
  }
});

/**
 * Migration hook - set creationComplete=true for existing characters without the flag
 * Also migrate old stone system to new per-attribute stone pools
 */
Hooks.once('ready', async function() {
  console.log('Mastery System | Running character creation migration...');
  
  // Get all character actors
  const characters = (game as any).actors?.filter((a: any) => a.type === 'character') || [];
  let migratedCreation = 0;
  let migratedStones = 0;
  
  for (const actor of characters) {
    const system = (actor as any).system;
    
    // Migration 1: creation.complete flag
    if (system?.creation?.complete === undefined || system?.creation?.complete === null) {
      await actor.update({ 'system.creation.complete': true });
      migratedCreation++;
    }
    
    // Migration 2: Old stone system -> new stonePools
    // Check if old system exists (system.stones.current/maximum) but new system doesn't (system.stonePools)
    const hasOldStones = system?.stones && (
      system.stones.current !== undefined || 
      system.stones.maximum !== undefined ||
      system.stones.total !== undefined
    );
    const hasNewStonePools = system?.stonePools && 
      Object.keys(system.stonePools).length > 0 &&
      system.stonePools.might !== undefined;
    
    if (hasOldStones && !hasNewStonePools) {
      console.log(`Mastery System | Migrating stone pools for ${actor.name}`);
      
      // Get old stone values
      const oldCurrent = system.stones?.current ?? 0;
      const oldMaximum = system.stones?.maximum ?? system.stones?.total ?? 0;
      
      // Initialize new stonePools structure
      const attributeKeys = ['might', 'agility', 'vitality', 'intellect', 'resolve', 'influence'] as const;
      const updates: any = {};
      
      // Calculate max for each pool based on attributes
      for (const attrKey of attributeKeys) {
        const attrValue = system.attributes?.[attrKey]?.value || 0;
        const maxStones = Math.floor(attrValue / 8);
        
        // Initialize pool
        if (!system.stonePools) {
          updates['system.stonePools'] = {};
        }
        
        updates[`system.stonePools.${attrKey}`] = {
          current: 0,
          max: maxStones,
          sustained: 0
        };
      }
      
      // Distribute old current stones evenly across all pools
      // Strategy: Distribute proportionally based on max capacity, but at least 1 per pool if possible
      const totalMax = attributeKeys.reduce((sum, key) => {
        const attrValue = system.attributes?.[key]?.value || 0;
        return sum + Math.floor(attrValue / 8);
      }, 0);
      
      if (totalMax > 0 && oldCurrent > 0) {
        let remaining = oldCurrent;
        
        for (const attrKey of attributeKeys) {
          const attrValue = system.attributes?.[attrKey]?.value || 0;
          const maxStones = Math.floor(attrValue / 8);
          
          // Proportional distribution
          const proportion = totalMax > 0 ? maxStones / totalMax : 0;
          const allocated = Math.floor(oldCurrent * proportion);
          
          // Ensure we don't exceed max for this pool
          const finalCurrent = Math.min(maxStones, allocated);
          
          updates[`system.stonePools.${attrKey}.current`] = finalCurrent;
          remaining -= finalCurrent;
        }
        
        // Distribute any remainder to pools that have capacity
        if (remaining > 0) {
          for (const attrKey of attributeKeys) {
            if (remaining <= 0) break;
            
            const pool = updates[`system.stonePools.${attrKey}`];
            if (pool.current < pool.max) {
              const add = Math.min(remaining, pool.max - pool.current);
              pool.current += add;
              remaining -= add;
            }
          }
        }
      }
      
      // Apply updates
      await actor.update(updates);
      migratedStones++;
      
      console.log(`Mastery System | Migrated stones for ${actor.name}: ${oldCurrent}/${oldMaximum} -> distributed across ${attributeKeys.length} pools`);
    }
  }
  
  if (migratedCreation > 0) {
    console.log(`Mastery System | Migrated ${migratedCreation} existing characters (set creationComplete=true)`);
  }
  
  if (migratedStones > 0) {
    console.log(`Mastery System | Migrated ${migratedStones} characters from old stone system to per-attribute pools`);
  }
});

/**
 * Ready hook - called when Foundry is fully loaded and ready
 */
Hooks.once('ready', async function() {
  console.log('Mastery System | System ready');
  
  // Log system version
  const system = (game as any).system;
  console.log(`Mastery System | Version ${system.version}`);
});

/**
 * Set default scene background image when creating new scenes
 */
Hooks.on('preCreateScene', (_scene: any, data: any, _options: any, _userId: string) => {
  // Only set default if no background image is provided
  if (!data.img && (!data.background || !data.background.src)) {
    const defaultImage = (game as any).settings.get('mastery-system', 'defaultSceneImage');
    if (defaultImage && defaultImage.trim() !== '') {
      // Set the background image - Foundry uses 'img' field for scene background
      data.img = defaultImage;
      console.log('Mastery System | Setting default scene background:', defaultImage);
    }
  }
});

/**
 * Add chat message context menu options
 */
Hooks.on('getChatLogEntryContext', (_html: JQuery, options: any[]) => {
  // Add re-roll option for Mastery rolls
  options.push({
    name: 'Re-Roll',
    icon: '<i class="fas fa-dice"></i>',
    condition: (li: JQuery) => {
      const message = (game as any).messages?.get(li.data('messageId'));
      return message?.getFlag('mastery-system', 'canReroll') === true;
    },
    callback: (li: JQuery) => {
      const message = (game as any).messages?.get(li.data('messageId'));
      // TODO: Implement re-roll logic
      console.log('Re-rolling:', message);
    }
  });
});

/**
 * Handle attack roll button clicks in chat
 * Use event delegation on the chat log container to catch all button clicks
 */
/**
 * Equip Exclusivity Hook
 * Ensures only one weapon/armor/shield can be equipped at a time
 */
Hooks.on('preUpdateItem', async (item: any, changes: any, _options: any, _userId: string) => {
  // Only process if this is the updating user
  if (_userId !== (game as any).user?.id) {
    return;
  }
  
  // Only process if item is embedded in an actor and equipped is being set to true
  if (!item.parent || item.parent.documentName !== 'Actor') {
    return;
  }
  
  const itemType = item.type;
  if (!['weapon', 'armor', 'shield'].includes(itemType)) {
    return;
  }
  
  if (changes.system?.equipped !== true) {
    return;
  }
  
  const actor = item.parent;
  const items = actor.items || [];
  
  // Find all other items of the same type that are equipped
  const otherEquippedItems = items.filter((otherItem: any) => {
    return otherItem.id !== item.id && 
           otherItem.type === itemType && 
           (otherItem.system as any)?.equipped === true;
  });
  
  if (otherEquippedItems.length > 0) {
    // Unequip all other items of the same type
    const updates = otherEquippedItems.map((otherItem: any) => ({
      _id: otherItem.id,
      'system.equipped': false
    }));
    
    await actor.updateEmbeddedDocuments('Item', updates);
    console.log(`Mastery System | Unequipped ${otherEquippedItems.length} other ${itemType}(s) when equipping ${item.name}`);
  }
});

Hooks.once('ready', async () => {
  // Register attack roll click handler
  registerAttackRollClickHandler();
  
  // Migration: Add default weapon to existing actors if missing
  console.log('Mastery System | Running equipment migration...');
  
  const actors = (game as any).actors?.filter((a: any) => 
    a.type === 'character' || a.type === 'npc'
  ) || [];
  
  let migrated = 0;
  
  for (const actor of actors) {
    try {
      const items = actor.items || [];
      const hasWeapon = items.some((item: any) => item.type === 'weapon');
      
      if (!hasWeapon) {
        const unarmedWeapon = {
          name: 'Unarmed',
          type: 'weapon',
          system: {
            weaponType: 'melee',
            damage: '1d8',
            range: '0m',
            specials: [],
            equipped: true,
            hands: 1,
            innateAbilities: [],
            description: 'Basic unarmed strikes using fists, feet, or natural weapons.'
          }
        };
        
        await actor.createEmbeddedDocuments('Item', [unarmedWeapon]);
        migrated++;
        console.log(`Mastery System | Added default "Unarmed" weapon to ${actor.name}`);
      }
    } catch (error) {
      console.warn(`Mastery System | Could not migrate actor ${actor.name}:`, error);
    }
  }
  
  if (migrated > 0) {
    console.log(`Mastery System | Migrated ${migrated} actors (added default weapon)`);
  }
  
  // Optional: Try to backfill armor/shield items from system.combat.armorName/shieldName
  // This is optional and only runs if utils/equipment.ts exists
  try {
    const equipmentModule = await import('./utils/equipment.js');
    if (equipmentModule.getAllArmor && equipmentModule.getAllShields) {
      let backfilled = 0;
      
      for (const actor of actors) {
        try {
          const system = (actor as any).system;
          const combat = system?.combat || {};
          const items = actor.items || [];
          
          // Check for armor
          if (combat.armorName && !items.some((item: any) => item.type === 'armor')) {
            const allArmor = equipmentModule.getAllArmor();
            const matchingArmor = allArmor.find((a: any) => a.name === combat.armorName);
            
            if (matchingArmor) {
              const armorItem = {
                name: matchingArmor.name,
                type: 'armor',
                system: {
                  type: matchingArmor.type || 'light',
                  armorValue: matchingArmor.armorValue || 0,
                  skillPenalty: matchingArmor.skillPenalty || 0,
                  equipped: true,
                  description: matchingArmor.description || ''
                }
              };
              
              await actor.createEmbeddedDocuments('Item', [armorItem]);
              backfilled++;
              console.log(`Mastery System | Backfilled armor "${combat.armorName}" for ${actor.name}`);
            } else {
              console.warn(`Mastery System | Could not find armor definition for "${combat.armorName}" (actor: ${actor.name})`);
            }
          }
          
          // Check for shield
          if (combat.shieldName && !items.some((item: any) => item.type === 'shield')) {
            const allShields = equipmentModule.getAllShields();
            const matchingShield = allShields.find((s: any) => s.name === combat.shieldName);
            
            if (matchingShield) {
              const shieldItem = {
                name: matchingShield.name,
                type: 'shield',
                system: {
                  type: matchingShield.type || 'light',
                  shieldValue: matchingShield.shieldValue || 0,
                  evadeBonus: matchingShield.evadeBonus || 0,
                  skillPenalty: matchingShield.skillPenalty || 0,
                  equipped: true,
                  description: matchingShield.description || ''
                }
              };
              
              await actor.createEmbeddedDocuments('Item', [shieldItem]);
              backfilled++;
              console.log(`Mastery System | Backfilled shield "${combat.shieldName}" for ${actor.name}`);
            } else {
              console.warn(`Mastery System | Could not find shield definition for "${combat.shieldName}" (actor: ${actor.name})`);
            }
          }
        } catch (error) {
          console.warn(`Mastery System | Could not backfill equipment for ${actor.name}:`, error);
        }
      }
      
      if (backfilled > 0) {
        console.log(`Mastery System | Backfilled ${backfilled} equipment items`);
      }
    }
  } catch (error) {
    // utils/equipment.ts doesn't exist or doesn't export the needed functions - that's okay
    console.log('Mastery System | Equipment backfill skipped (utils/equipment.js not available)');
  }
  
  // Migration: Fix stone pool current values for existing actors
  console.log('Mastery System | Running stone pool migration...');
  
  const characterActors = (game as any).actors?.filter((a: any) => a.type === 'character') || [];
  let stonePoolsFixed = 0;
  
  for (const actor of characterActors) {
    try {
      const system = (actor as any).system;
      const stonePools = system?.stonePools || {};
      const attributes = system?.attributes || {};
      const attributeKeys = ['might', 'agility', 'vitality', 'intellect', 'resolve', 'influence'] as const;
      
      const updates: Record<string, any> = {};
      let needsUpdate = false;
      
      for (const attrKey of attributeKeys) {
        const pool = stonePools[attrKey];
        if (!pool) continue;
        
        const attrValue = attributes[attrKey]?.value || 0;
        const maxStones = Math.floor(attrValue / 8);
        const sustained = pool.sustained ?? 0;
        const effectiveMax = Math.max(0, maxStones - sustained);
        
        // Only fix if max > 0 (actor has stones)
        if (maxStones > 0) {
          // Fix if current is undefined/null OR if current is 0 and actor is not in active combat
          const isInCombat = game.combat?.active && game.combat.combatants.some((c: any) => c.actor?.id === actor.id);
          const shouldFix = pool.current === undefined || 
                           pool.current === null || 
                           (pool.current === 0 && !isInCombat);
          
          if (shouldFix) {
            updates[`system.stonePools.${attrKey}.current`] = effectiveMax;
            updates[`system.stonePools.${attrKey}.max`] = maxStones;
            needsUpdate = true;
          }
        }
      }
      
      if (needsUpdate) {
        await actor.update(updates);
        stonePoolsFixed++;
        console.log(`Mastery System | Fixed stone pools for ${actor.name}`);
      }
    } catch (error) {
      console.warn(`Mastery System | Could not migrate stone pools for ${actor.name}:`, error);
    }
  }
  
  if (stonePoolsFixed > 0) {
    console.log(`Mastery System | Migrated ${stonePoolsFixed} actors (fixed stone pool current values)`);
  }
});

/**
 * Log system information
 */
console.log(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║            MASTERY SYSTEM / DESTROYED FAITH               ║
║                                                           ║
║  A dark fantasy tabletop RPG system featuring:            ║
║  • Roll & Keep d8 dice mechanics                          ║
║  • Attribute Stones & Mastery Ranks                       ║
║  • Health Bars with cumulative penalties                  ║
║  • Powers & Mastery Trees (L1-L4)                         ║
║  • Divine Clash late-game combat                          ║
║                                                           ║
       ║  Version: 0.2.0                                            ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
`);

