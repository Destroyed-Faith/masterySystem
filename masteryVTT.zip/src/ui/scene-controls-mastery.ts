/**
 * Scene Controls - Mastery Quick Access Menu
 * Adds a "Mastery" group to the left Scene Controls toolbar
 */

import { PassiveSelectionDialog } from '../sheets/passive-selection-dialog.js';
import { InitiativeShopDialog } from '../combat/initiative-shop-dialog.js';
import { StonePowersDialog } from '../stones/stone-powers-dialog.js';
import { CombatCarouselApp } from './combat-carousel.js';
import { ThemePreviewApp } from './theme-preview.js';
import { rollInitiativeForCombatant } from '../combat/initiative-roll.js';
import { showDamageDialog } from '../dice/damage-dialog.js';

/**
 * Resolve the active actor from selected token or user character
 */
function resolveActiveActor(): Actor | null {
  const controlled = canvas?.tokens?.controlled || [];
  if (controlled.length > 0 && controlled[0].actor) {
    return controlled[0].actor;
  }
  
  if (game.user?.character) {
    return game.user.character;
  }
  
  return null;
}

/**
 * Resolve combatant for active actor
 */
function resolveCombatant(actor: Actor): Combatant | null {
  if (!game.combat) return null;
  
  return game.combat.combatants.find((c: Combatant) => c.actor?.id === (actor as any).id) || null;
}

/**
 * Initialize scene controls
 */
export function initializeSceneControls(): void {
  console.log('Mastery System | Initializing scene controls');

  Hooks.on('getSceneControlButtons', (controls: any) => {
    // In Foundry v13, controls is a Record (object), not an array
    // Add controls directly as properties
    
    // Define tool handlers as separate functions to ensure they're properly bound
    const handleThemePreview = async function() {
      console.log('Mastery System | Theme Preview clicked');
      await ThemePreviewApp.show();
    };
    
    const handlePassiveSelection = async function() {
      console.log('Mastery System | Passive Selection clicked');
      const actor = resolveActiveActor();
      if (!actor) {
        ui.notifications?.warn('Select a token or assign a User Character first.');
        return;
      }

      // If in combat, use combatant; otherwise create dummy combatant for preview
      const combatant = resolveCombatant(actor);
      if (combatant) {
        // In combat: use existing dialog
        await PassiveSelectionDialog.showForCombatant(combatant, false);
      } else {
        // Not in combat: create dummy combatant for preview
        ui.notifications?.info('Opening Passive Selection in preview mode (not in combat).');
        ui.notifications?.warn('Passive Selection is only available during combat. Start a combat encounter first.');
      }
    };
    
    const handleInitiativeShop = async function() {
      console.log('Mastery System | Initiative Shop clicked');
      const actor = resolveActiveActor();
      if (!actor) {
        ui.notifications?.warn('Select a token or assign a User Character first.');
        return;
      }

      const combatant = resolveCombatant(actor);
      if (combatant && game.combat) {
        // In combat: roll initiative and show shop
        const breakdown = await rollInitiativeForCombatant(combatant);
        await InitiativeShopDialog.showForCombatant(combatant, breakdown, game.combat);
      } else {
        // Not in combat: show preview with dummy context
        ui.notifications?.info('Initiative Shop is only available during combat. Start a combat encounter first.');
      }
    };
    
    const handleStonePowers = async function() {
      console.log('Mastery System | Stone Powers clicked');
      const actor = resolveActiveActor();
      if (!actor) {
        ui.notifications?.warn('Select a token or assign a User Character first.');
        return;
      }

      const combatant = resolveCombatant(actor);
      await StonePowersDialog.showForActor(actor, combatant || null);
    };
    
    const handleDamageDialogTest = async function() {
      console.log('Mastery System | Damage Dialog Test clicked');
      const actor = resolveActiveActor();
      if (!actor) {
        ui.notifications?.warn('Select a token or assign a User Character first.');
        return;
      }

      // Try to get a target
      const targets = Array.from(canvas?.tokens?.controlled || []);
      let targetActor: Actor | null = null;
      
      if (targets.length > 1) {
        // Use second selected token as target
        targetActor = (targets[1] as any)?.actor || null;
      } else {
        // Try to find a nearby token or use the same actor
        targetActor = actor;
      }

      if (!targetActor) {
        ui.notifications?.warn('Select a target token for damage testing.');
        return;
      }

      // Open damage dialog with dummy data
      try {
        await showDamageDialog(
          actor,
          targetActor,
          null, // weaponId
          null, // selectedPowerId
          0,    // raises
          {}    // flags
        );
      } catch (error) {
        console.error('Mastery System | Error opening damage dialog', error);
        ui.notifications?.error('Failed to open damage dialog. Check console for details.');
      }
    };
    
    const handleCarouselRefresh = function() {
      console.log('Mastery System | Carousel Refresh clicked');
      const instance = CombatCarouselApp.instance;
      if (instance && (instance as any).rendered) {
        CombatCarouselApp.refresh();
        ui.notifications?.info('Combat Carousel refreshed.');
      } else {
        CombatCarouselApp.open();
        ui.notifications?.info('Combat Carousel opened.');
      }
    };
    
    // Add Mastery group directly to controls object
    controls.mastery = {
      name: 'mastery',
      title: 'Mastery',
      icon: 'fas fa-gem',
      layer: 'TokenLayer',
      tools: [
        {
          name: 'themePreview',
          title: 'Theme Preview',
          icon: 'fas fa-palette',
          onClick: handleThemePreview,
          button: true
        },
        {
          name: 'passiveSelection',
          title: 'Passive Selection',
          icon: 'fas fa-shield-halved',
          onClick: handlePassiveSelection,
          button: true
        },
        {
          name: 'initiativeShop',
          title: 'Initiative Shop',
          icon: 'fas fa-dice-d20',
          onClick: handleInitiativeShop,
          button: true
        },
        {
          name: 'stonePowers',
          title: 'Stone Powers',
          icon: 'fas fa-gem',
          onClick: handleStonePowers,
          button: true
        },
        {
          name: 'damageDialogTest',
          title: 'Damage Dialog Test',
          icon: 'fas fa-burst',
          onClick: handleDamageDialogTest,
          button: true
        },
        {
          name: 'carouselRefresh',
          title: 'Carousel Refresh',
          icon: 'fas fa-arrows-rotate',
          onClick: handleCarouselRefresh,
          button: true
        }
      ],
      activeTool: '',
      visible: true,
      button: true
    };
    
    console.log('Mastery System | Scene controls added:', controls.mastery);
  });
}

/**
 * Initialize Token HUD button for Stone Powers
 */
export function initializeTokenHUDButton(): void {
  Hooks.on('renderTokenHUD', (_hud: any, html: JQuery, token: Token) => {
    // Only show for character actors
    const actor = token.actor;
    if (!actor || actor.type !== 'character') return;

    // Find the right column (where other buttons are)
    const rightColumn = html.find('.col.right');
    if (rightColumn.length === 0) return;

    // Create Stone Powers button
    const stonePowersBtn = $(`
      <div class="control-icon ms-stone-powers-hud" 
           data-action="openStonePowers" 
           data-tooltip="Stone Powers"
           aria-label="Stone Powers"
           title="Stone Powers">
        <i class="fas fa-gem"></i>
      </div>
    `);

    // Add click handler
    stonePowersBtn.on('click', async (ev: JQuery.ClickEvent) => {
      ev.preventDefault();
      ev.stopPropagation();

      if (!actor) {
        ui.notifications?.error('Actor not found');
        return;
      }

      try {
        const combatant = resolveCombatant(actor);
        await StonePowersDialog.showForActor(actor, combatant || null);
      } catch (error) {
        console.error('Mastery System | Error showing stone powers dialog', error);
        ui.notifications?.error('Failed to open stone powers dialog');
      }
    });

    // Insert before the last element (or append if empty)
    if (rightColumn.children().length > 0) {
      rightColumn.append(stonePowersBtn);
    } else {
      rightColumn.append(stonePowersBtn);
    }
  });
}
